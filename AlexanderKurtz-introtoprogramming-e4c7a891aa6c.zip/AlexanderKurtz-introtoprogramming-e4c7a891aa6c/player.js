function Player(location){
	this.location = location;
	this.inventory = [];
	this.points = 0;
}
